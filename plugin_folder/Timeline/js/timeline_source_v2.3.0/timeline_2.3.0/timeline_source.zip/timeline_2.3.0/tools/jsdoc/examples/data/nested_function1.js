﻿record = {
    remove: function() {
    }
};

record.refresh = function(record) {
}

/*
[
    {
        symbols: [
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "FUNCTION",
                desc: "undocumented",
                alias: "record.remove",
                memberof: "",
                params: [],
                methods: [],
                name: "record.remove"
            },
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "FUNCTION",
                desc: "undocumented",
                alias: "record.refresh",
                memberof: "",
                params: [
                    {
                        title: "param",
                        desc: "",
                        type: "",
                        name: "record",
                        isOptional: false
                    }
                ],
                methods: [],
                name: "record.refresh"
            }
        ],
        overview: {
            doc: { tags: [] },
            returns: [],
            type: "",
            properties: [],
            isa: "FILE",
            desc: "No overview provided.",
            alias: "examples/data/nested_function1.js",
            memberof: "",
            params: [],
            methods: [],
            name: "examples/data/nested_function1.js"
        }
    }
]
*/